# Champions Athletic Map

Exercise classification and four workflows for weekly basketball planning

## ABSTRACT

We developed Champions Athletic Map as a local prototype for weekly basketball planning for athletes ages 13–17. The project combines exercise-text classification, source-linked basketball references, recorded food facts and an interface for viewing, editing and tracking saved plans. We compared a majority baseline, TF-IDF with logistic regression, and a small neural classifier trained from scratch. Separately, we evaluated four planning workflows using the same local Llama 3.1 8B model: generation alone, generation with references, specialist contributions, and specialist planning with checks and bounded revisions. The held-out exercise test contained 438 records in 385 groups. Logistic regression achieved the highest observed Macro-F1, 0.6143, and accuracy, 73.29%, compared with 0.5288 and 67.81% for the neural classifier. The planner comparison produced 800 saved outcomes from 200 fictional profiles. Correct-format responses ranged from 62 to 75 of 200 per workflow, and none of the 150 feasible requests per workflow achieved full verification. Both actual output errors and incomplete checking coverage contributed to this result. More involved workflows did not consistently improve the recorded measures and required more time. A separate-environment replay reproduced 37 saved analysis outputs under the declared comparison rules. These findings support the exercise classifier and the reproducible analysis while identifying substantial work needed for reliable end-to-end planning.

## KEYWORDS

Youth basketball; text classification; retrieval-augmented generation; language models; constraint checking; reproducibility

## 1 Introduction

Planning extra basketball practice involves more than choosing a drill. A useful weekly schedule must fit the athlete's available time, preserve existing practices and games, account for equipment and space, and remain clear about information that has not been supplied. Our intended users are teenage basketball athletes, their parents and coaches. The proposed product is a planning workspace that brings these facts together and makes its recommendations easy to inspect and adjust.

Large language models can produce fluent instructions, but fluency does not establish that a schedule respects a request. References can make relevant information available, specialist roles can divide the task, and evaluators can request revisions. Each addition also creates another opportunity for an incomplete response, an incorrect interpretation or an execution problem. We therefore studied these additions as complete workflows rather than assume that a more elaborate arrangement would produce better plans.

Our main research question was whether references, specialist contributions and checks with bounded revisions would improve recorded planning reliability compared with a language model alone. We considered response structure, completed workflows, fulfillment of explicit constraints and local execution time. A separate classification experiment asked how well statistical and neural text models could identify a supported body-part category from an exercise description. The classification task supports exercise-data organization; it does not determine whether an exercise is suitable for an individual athlete.

We built and evaluated the system with fictional profiles. Its scope is general basketball-planning support and recorded food facts. It does not diagnose injuries, prescribe rehabilitation or provide individualized diets. We did not measure improvements in athletic performance. The final evaluation instead examines whether the implemented system handles its stated inputs and produces responses that can be verified against the supplied requirements.

## 2 Data Summary

### 2.1 Exercise data and preparation

The exercise source was the Gym Exercise Dataset published by niharika41298 (n.d.) on Kaggle and supplied through the team's cleaned data package. Our registered source contained 2,909 exercise records with 17 body-part labels. Records included names and, where available, descriptions, equipment, exercise type and difficulty. We used the name and available description as classifier input. We excluded equipment, difficulty, identifiers and review fields from the predictive features so the models would learn from exercise text rather than fields that could reveal or distort the target.

Missing descriptions were common: 1,550 source records lacked them. We retained eligible name-only examples instead of inventing instructions. The final benchmark included 1,540 such records. We grouped related exercise records before splitting to reduce overlap between similar examples in training and evaluation. We excluded 37 records from the classifier benchmark while preserving the original records: 22 had unresolved same-name target conflicts, eight belonged to a class with insufficient distinct-group support, and seven had unresolved source-field inconsistencies. The excluded low-support class was neck. The resulting benchmark contained 2,872 records in 2,563 groups and 16 classes.

Table 1 reports the actual frozen split. Every partition retained all 16 classes. Fixed text normalization was applied consistently, while the TF-IDF vocabulary and feature statistics and the neural vocabulary and sequence settings were learned from training only. Validation supported tuning and checkpoint selection; the held-out test was reserved for the final classifier comparison. The proportions are approximate because splitting preserved groups rather than divide individual records independently.

TABLE:split

### 2.2 Basketball resources and fictional profiles

The source inventory also included the merged master dataset, basketball teaching records, youth participation guidance and food data. The master contained 256,337 records from several domains. We loaded it for source auditing and exploratory analysis; it was not an athlete-by-exercise training table, and we did not train the classifiers on all of its rows. Derived versions and overlapping source packages were kept separate rather than added together as independent observations.

Basketball teaching material included the official Jr. NBA/Jr. WNBA curriculum (National Basketball Association [NBA], n.d.). Our resource activation recorded 127 available basketball records, nine general warm-ups and 29 rule definitions, with seven drill records held. These are resource-release counts rather than a claim that every row is a distinct drill suitable for every teenager. General gym exercise records remained unavailable to the planner. Source eligibility, rule-definition adoption and implemented compliance checking were separate decisions.

The optional food lookup used a frozen 100-food SR Legacy reference with food-specific recorded portions. Earlier Foundation Foods data remained a separate source. FoodData Central distinguishes these data types, including the historical SR Legacy release and its underlying nutrient records (U.S. Department of Agriculture, Agricultural Research Service [USDA ARS], n.d.). Our lookup performed source-linked calculations for a selected food and amount; it did not prescribe intake.

For the planner study, we prepared and reviewed 200 fictional profiles spanning ages 13–17. They included 150 feasible planning requests, 20 missing-information cases, 15 conflicting-constraint cases and 15 outside-scope cases. Public inputs described goals, availability, commitments, equipment, practice space, participants and limits on extra training. Private review expectations were kept outside model inputs. Source-linked activity examples and case decisions were frozen before the final comparison.

## 3 Literature Review

Published youth basketball resources provide organized instructional content and participation guidance. The Jr. NBA/Jr. WNBA curriculum offers four teaching levels with twelve practice plans per level (NBA, n.d.). The NBA and USA Basketball also publish age- and stage-oriented guidance for participation and rest (NBA & USA Basketball, n.d.). These sources help define the information a planning system should consider. They do not validate an AI-generated calendar or establish that a particular activity is appropriate for an individual athlete.

Text classification offers a separate way to organize written exercise information. Statistical models can learn associations between weighted text features and labels, with scikit-learn providing consistent implementations for feature extraction, classification and evaluation (Pedregosa et al., 2011). Iyyer et al. (2015) studied deep averaging networks that average token embeddings and pass the resulting representation through feedforward layers. Their results motivated relatively simple neural text architectures, although the strongest reported variants used pretrained embeddings and additional techniques. Averaging also discards word order. Performance on their sentiment and question-answering tasks does not establish performance on exercise descriptions.

Semantic retrieval matches related expressions beyond exact word overlap. Sentence-BERT encodes sentences separately so their representations can be compared efficiently, including by cosine similarity (Reimers & Gurevych, 2019). The released all-MiniLM-L6-v2 model produces 384-dimensional sentence representations for similarity and search (Sentence Transformers, n.d.). Similarity scores describe a relationship between texts; they do not establish source accuracy, answerability or whether a passage contains every fact needed for a response.

Language models can use retrieved context when generating an answer. Llama 3.1 includes an eight-billion-parameter autoregressive Transformer and instruction-tuned variants (Meta, 2024). In retrieval-augmented generation, Lewis et al. (2020) combined a pretrained generator with a dense document index and neural retrieval, reporting improvements on knowledge-intensive tasks. Their system used task-specific fine-tuning. An application that inserts references into an unchanged local model is therefore an implementation to evaluate directly, rather than a reproduction of all results in the original RAG study.

Work on agents and revision suggests additional ways to organize generation. AutoGen supports configurable conversations involving language models and tools, with demonstrations across several non-sports tasks (Wu et al., 2023). Self-Refine uses one model to generate an answer, provide feedback and revise without additional training, reporting gains on its evaluated tasks (Madaan et al., 2023). In contrast, Huang et al. (2024) found that intrinsic self-correction without external feedback could fail to improve reasoning and could reduce performance. These findings motivate separating an evaluator's opinion from checks against explicit requirements. They do not show that specialist roles or revision loops consistently improve youth basketball planning.

The literature supports investigating classification, retrieval and guided generation while preserving the evidence behind each component. It leaves a practical question for this project: whether a locally implemented combination can retain source information and satisfy the scheduling constraints supplied by an athlete. We address that question through matched workflow comparisons and saved assessments, rather than infer effectiveness from upstream language-model benchmarks.

## 4 Methodology

### 4.1 Classifier training and selection

We compared a training-majority baseline, a TF-IDF logistic classifier and a small neural classifier. The logistic implementation used scikit-learn (Pedregosa et al., 2011). Its word features included unigrams and bigrams, a maximum of 10,000 features, smoothed inverse document frequency and L2 normalization. Preparation was applied once through the saved tokenizer. We evaluated regularization values of 0.1, 1 and 10 with and without balanced class weights. The selected L5 model used L2 regularization, C = 10 and balanced class weights. Its optimizer was lbfgs, with tolerance 0.0001 and a maximum of 1,000 iterations.

The neural model was implemented in PyTorch (Paszke et al., 2019) and trained from scratch. It used a training-derived vocabulary of 1,748 tokens, 64-dimensional embeddings and a masked mean over non-padding tokens. A 64-unit dense layer with ReLU activation was followed by dropout and a 16-class output layer returning logits. It was a small averaging network rather than a recurrent or convolutional model. The saved sequence limit was 81 tokens, so longer inputs were truncated under the recorded policy.

The selected N3 configuration used dropout 0.2, AdamW with learning rate 0.001 and weight decay 0.0001, batch size 32 and a maximum of 30 epochs. Weighted cross-entropy used class frequencies from training. Early stopping monitored validation Macro-F1 with patience five. Neural configuration selection used the complete mean across development seeds 42, 17 and 73; its designated comparison artifact remained the best checkpoint from seed 42 rather than the best-performing seed. Selection compared the actual chosen logistic and neural artifacts using the frozen validation rule. The final held-out comparison used the saved fitted models without a combined training-and-validation refit.

Macro-F1 was primary because category support was uneven. Accuracy, class metrics and confusion counts provided context. The analysis retained all 16 classes, including in resampling. Classifier uncertainty used 2,000 paired exercise-group bootstrap draws with seed 42. This evaluates sensitivity to the saved test groups, not variability from retraining.

### 4.2 Reference tools and planning workflows

We compared lexical and semantic reference methods during development and froze the selected semantic route. We used the released all-MiniLM-L6-v2 encoder for inference rather than train it. The indexed corpus contained eleven passage cores with required contextual companions. Python methods supplied reference search, approved-drill lookup, adopted rule definitions and structured food lookup. Native language-model tool calling was not enabled.

All four planners used the same saved local Ollama llama3.1:8b artifact. We did not train or fine-tune the language model. Complete rendered requests were checked against the configured context with role-specific output space reserved. Public inputs, reference packets, original replies and validation outcomes were recorded. Transport uncertainty, execution failure and an invalid response were not silently repaired or replaced by another planner.

Planner 1 generated from athlete input alone. Planner 2 added a reference packet. Planner 3 added prompted contributions for training and recovery, plus a food role when a food question was present, before a coordinator produced the response. These were calls to the same model using our Python orchestration, rather than independent trained expert models. Planner 4 began with specialist drafting and added coded checks, an evaluator and bounded revisions. The final response contract was shared across versions. Planners 2–4 used the same reference packet for a matched case.

TABLE:workflows

### 4.3 Evaluation and recorded outcomes

The final study scheduled one designated outcome for every profile-workflow pair, giving 800 outcomes. Each outcome could include several internal model calls. We retained failures and incomplete workflows within their applicable denominators. The comparison used four matched contrasts: Version 2 minus 1, Version 3 minus 2, Version 4 minus 3, and Version 4 minus 1.

We kept response-format validity, workflow completion, correctly formatted completed plans, coded-check success and full verification separate. Feasible-plan measures used all 150 feasible profiles per workflow. Missing-information, conflicting-constraint and outside-scope cases retained their own denominators. A valid plan response had to meet the structural contract and declare a plan, but that alone did not establish compliance with the request. The automatic goal check was unfinished, and resource checking covered only some descriptions. Checks retained met, violated, unknown and not-applicable states; unknown results were not converted to passes.

The saved retrieval evaluation contained 30 held-out questions in 15 families. The source labels were 20 supported, two partly supported and eight unsupported. Ranking metrics used the original 24 questions with nonempty relevant-reference sets; complete evidence-set coverage used 20 supported questions. The early planned answerability split and the saved source denominators differed. We preserved both the discrepancy and the actual scored populations rather than relabel cases after inspecting results.

The supplementary team review covered a prespecified sample of 40 profiles, producing 160 replies and 800 entries across response suitability, profile fit, practicality and completeness, evidence accuracy, and clarity. It was one ChatGPT-assisted assessment under the project lead's direction. The original two-independent-teammate component was not collected, so agreement was not estimated. Ratings were kept separate by dimension without a combined score. The sample had 25 feasible and 15 challenge profiles.

For planner uncertainty, we retained 2,000 paired family-group resamples with seed 42 and individual percentile intervals. The final feasible set had 150 adopted family IDs, each with one profile. A sensitivity analysis retained the original wording-pattern grouping; only three wording patterns were present among feasible cases. Random-generator, group-order and interpolation details for planner calculations were clarified at analysis time after output exposure and recorded in the method note. The classifier's corresponding numerical conventions had already been frozen. We did not introduce formal significance tests or a new passing threshold.

### 4.4 Application and reproducibility

The Streamlit interface manages fictional profiles, saved responses, edits, self-reported progress and CSV or JSON exports. Saved edits create a new plan version, refresh coded checks and make earlier model assessments historical. Snapshot restoration validates the imported structure and resolves compatible resources. The application has a separate readiness gate: completing research runs does not automatically enable live generation or model review in the interface.

The recorded development setup used Windows, Python 3.12.6, an Intel i7-12700 processor, approximately 64 GiB RAM and an RTX 3080 with 10 GiB graphics memory. Timing results concern this local workflow and setup. We prepared a dedicated results-only notebook for reproduction. It copied required saved evidence into a separate environment, installed the recorded analysis dependencies, ran in a fresh kernel and compared the derived outputs using declared exact and numerical-tolerance rules. Original inputs were checked before and after. This route did not retrain classifiers or submit new planner requests.

## 5 Results

### 5.1 Exercise classification

Table 3 shows the held-out classifier results. L5 had the highest observed Macro-F1 and accuracy among the tested models. Both learned models improved substantially on the majority baseline, whose accuracy alone concealed weak performance across the full class list. These results support exercise-text labeling within the tested taxonomy. They do not establish exercise eligibility or basketball-plan quality.

TABLE:classifiers

The N3 seed-42 run selected epoch 19 and stopped at epoch 24 after five epochs without validation Macro-F1 improvement. The restored checkpoint had validation Macro-F1 0.5711. Figure 1 shows the saved learning history. Between epochs 19 and 24, training loss fell from 0.6477 to 0.5050 while validation loss rose from 1.6817 to 1.7629. This late-stage divergence is consistent with overfitting and supports retaining the earlier checkpoint. The final neural test Macro-F1 was 0.5288. We do not treat the neural architecture as superior simply because it is more complex than the logistic model.

FIGURE:learning

The selected neural configuration's three-seed validation mean Macro-F1 was 0.5625, with descriptive sample standard deviation 0.0088. Those repetitions informed development selection; they were not new test-set repetitions. L5 remained the validation-selected tagging model when the test results became available.

### 5.2 Reference search and planning

Mean Recall@5 was 1.0000 and MRR@5 was 0.9792 across the 24 ranking-eligible questions. Complete ranked evidence-set coverage@5 was 1.0000 across the 20 supported questions. All 30 queries returned candidates, including unsupported questions. These results describe retrieval ranking. They do not show correct abstention or prove that every required fact reached, or was correctly used by, a planner.

Tables 4 and 5 separate execution and format results from feasible-plan verification. The full comparison produced all 800 designated outcomes and used 2,636 cumulative model submissions, including specialist, evaluator and revision calls. Planner 1 had the most correctly formatted responses across all profiles and the lowest median time. Planner 4 produced 47 correctly formatted completed plans for feasible requests, compared with 45, 40 and 39 for the other versions, but required considerably more time.

TABLE:execution

TABLE:plans

FIGURE:planning

No feasible plan passed the full-verification measure, and none passed the separate coded-check measure. Missing automatic goal verification and limited activity-resource recognition prevented complete assessment. The saved results also contained actual violations, including missing or changed practices, incorrect numbers of sessions and exceeded limits for extra training. The zero-success outcome therefore cannot be explained only by an unfinished checker. Conversely, an unverified plan is not automatically proved unsafe or useless.

The challenge results exposed additional limitations. Missing-information handling was 0/20 for every workflow, and conflicting-constraint handling was 0/15 for every workflow under the recorded checks. Outside-scope success was 3/15, 5/15, 8/15 and 3/15 for Versions 1–4. Planner 4 internally accepted none of its final outcomes: 198 reached the revision-limit terminal state and two ended with execution errors. Its high workflow-completion count should therefore not be read as an acceptance or quality rate.

The format-rate differences for the four prespecified contrasts were -6.5, +2.5, +1.0 and -3.0 percentage points. These are descriptive differences in a structural measure. With every primary verification flag equal to zero, the corresponding saved-output bootstrap differences and intervals were constant at zero. This does not establish equivalent underlying quality or zero uncertainty outside the benchmark.

### 5.3 Team review and application behavior

The supplementary review retained 799 numeric entries and one justified evidence-accuracy entry marked not applicable. Matched comparisons reported higher, equal and lower ratings separately for each dimension. On the clarity dimension, Version 4 versus Version 1 had two higher ratings, 15 equal and 23 lower among the 40 reviewed profiles. This is descriptive evidence from one assisted review rather than independent-rater agreement. Because challenge profiles were overrepresented in the sample, its pooled ratings do not estimate all final replies.

Local interface checks confirmed that users could load saved examples, change session times and durations, record completion, download snapshots and restore compatible saved edits and progress. These checks concern application state and file behavior. They do not establish that the original generated schedules were correct. Live planning and model review remained controlled by the separate application readiness gate.

### 5.4 Reproducibility and limitations

The separate-environment analysis replay passed 37 output-file comparisons and left protected originals unchanged. It made no new model calls. This verifies the recorded saved-analysis route rather than a complete rerun of preparation, training and live generation. The project retained its original outcomes, method amendments and checking limitations throughout analysis and documentation.

The results concern constructed profiles, one local planning model and one designated final outcome per profile and workflow. They do not estimate variability from repeated generations or performance on real athletes. The feasible profiles shared three original wording patterns despite their distinct adopted family IDs. Retrieval evaluation was small and distinct from the planner's merged packet. Goal and resource checks were incomplete, and independent review was not collected. Some planner resampling conventions were clarified after output exposure. These limits prevent a broad claim that one planner is generally best or that the prototype is ready for independent athletic guidance.

## 6 Conclusion

We completed an exercise-classification experiment, four matched planning workflows, a local interface and a reproducible analysis of the saved evidence. L5 logistic regression performed best among the tested classifiers, while semantic retrieval ranked relevant material highly in its saved evaluation. The planner comparison gave a less favorable result: additional references, specialist contributions and revisions did not consistently improve reliability, and no feasible plan achieved full verification.

Our next development priority is to move calendar construction into explicit scheduling logic that preserves commitments, enforces availability and counts sessions and minutes. The language model can then describe and explain a schedule that has already passed those numerical checks. Approved drill identifiers should retain verified equipment, space and participant requirements, and food values should be displayed directly from their lookup records. Completing goal and resource checks, simplifying the generation contract and collecting separate team and qualified basketball feedback would provide a stronger basis for another evaluation.

Changes informed by these exposed final cases belong to a new experiment with fresh evaluation cases. The present work provides evidence about the prototype's capabilities and failure modes, rather than a claim of improved athletic performance or validated youth coaching.

## ACKNOWLEDGMENTS

We used OpenAI ChatGPT (OpenAI, n.d.) to assist with code development, debugging, literature checking, drafting and export preparation, and to conduct the single supplementary response assessment described in the methods. Local experiments were run in the project environment with their original outputs retained. The assisted assessment was not an independent coaching review or a substitute for the uncollected two-reviewer study.

## Works Cited

Huang, J., Chen, X., Mishra, S., Zheng, H. S., Yu, A. W., Song, X., & Zhou, D. (2024). Large language models cannot self-correct reasoning yet. In The Twelfth International Conference on Learning Representations. https://proceedings.iclr.cc/paper_files/paper/2024/hash/8b4add8b0aa8749d80a34ca5d941c355-Abstract-Conference.html

Iyyer, M., Manjunatha, V., Boyd-Graber, J., & Daumé III, H. (2015). Deep unordered composition rivals syntactic methods for text classification. In Proceedings of the 53rd Annual Meeting of the Association for Computational Linguistics and the 7th International Joint Conference on Natural Language Processing (Volume 1: Long Papers) (pp. 1681–1691). Association for Computational Linguistics. https://doi.org/10.3115/v1/P15-1162

Lewis, P., Perez, E., Piktus, A., Petroni, F., Karpukhin, V., Goyal, N., Küttler, H., Lewis, M., Yih, W.-t., Rocktäschel, T., Riedel, S., & Kiela, D. (2020). Retrieval-augmented generation for knowledge-intensive NLP tasks. Advances in Neural Information Processing Systems, 33. https://proceedings.neurips.cc/paper/2020/hash/6b493230205f780e1bc26945df7481e5-Abstract.html

Madaan, A., Tandon, N., Gupta, P., Hallinan, S., Gao, L., Wiegreffe, S., Alon, U., Dziri, N., Prabhumoye, S., Yang, Y., Gupta, S., Majumder, B. P., Hermann, K., Welleck, S., Yazdanbakhsh, A., & Clark, P. (2023). Self-Refine: Iterative refinement with self-feedback [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2303.17651

Meta. (2024). Llama 3.1 model card [Model card]. GitHub. https://github.com/meta-llama/llama-models/blob/main/models/llama3_1/MODEL_CARD.md

National Basketball Association. (n.d.). Jr. NBA/Jr. WNBA instructional curriculum. https://jr.nba.com/jr-nba-instructional-curriculum/

National Basketball Association & USA Basketball. (n.d.). Youth basketball guidelines. https://youthguidelines.nba.com/

niharika41298. (n.d.). Gym Exercise Dataset [Dataset]. Kaggle. https://www.kaggle.com/datasets/niharika41298/gym-exercise-data

OpenAI. (n.d.). ChatGPT [Large language model]. https://chatgpt.com/

Paszke, A., Gross, S., Massa, F., Lerer, A., Bradbury, J., Chanan, G., Killeen, T., Lin, Z., Gimelshein, N., Antiga, L., Desmaison, A., Kopf, A., Yang, E., DeVito, Z., Raison, M., Tejani, A., Chilamkurthy, S., Steiner, B., Fang, L., ... Chintala, S. (2019). PyTorch: An imperative style, high-performance deep learning library. Advances in Neural Information Processing Systems, 32. https://papers.neurips.cc/paper_files/paper/2019/hash/bdbca288fee7f92f2bfa9f7012727740-Abstract.html

Pedregosa, F., Varoquaux, G., Gramfort, A., Michel, V., Thirion, B., Grisel, O., Blondel, M., Prettenhofer, P., Weiss, R., Dubourg, V., Vanderplas, J., Passos, A., Cournapeau, D., Brucher, M., Perrot, M., & Duchesnay, É. (2011). Scikit-learn: Machine learning in Python. Journal of Machine Learning Research, 12(85), 2825–2830. https://jmlr.org/papers/v12/pedregosa11a.html

Reimers, N., & Gurevych, I. (2019). Sentence-BERT: Sentence embeddings using Siamese BERT-networks. In Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing and the 9th International Joint Conference on Natural Language Processing (pp. 3982–3992). Association for Computational Linguistics. https://doi.org/10.18653/v1/D19-1410

Sentence Transformers. (n.d.). all-MiniLM-L6-v2 [Model card]. Hugging Face. https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2

U.S. Department of Agriculture, Agricultural Research Service. (n.d.). FoodData Central data type documentation. https://fdc.nal.usda.gov/data-documentation/

Wu, Q., Bansal, G., Zhang, J., Wu, Y., Li, B., Zhu, E., Jiang, L., Zhang, X., Zhang, S., Liu, J., Awadallah, A. H., White, R. W., Burger, D., & Wang, C. (2023). AutoGen: Enabling next-gen LLM applications via multi-agent conversation [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2308.08155
