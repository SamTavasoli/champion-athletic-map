Champions Athletic Map notebook PDF exports

Start with Champions_Athletic_Map_Notebook_Reading_Copy.pdf.
It contains all notebook explanations and saved outputs, together with clearly
labeled short code excerpts and page references to the complete code appendix.

Champions_Athletic_Map_Complete_Code_Appendix.pdf contains every original code
cell, including the long embedded source/data payloads. Its length reflects
the existing notebook source; it is a reference volume rather than the report.
Use the PDF bookmarks to find a notebook cell by its zero-based index.

The two PDFs belong together. The reading copy is not a complete code export
by itself. The unchanged .ipynb and the exported .py remain the executable
source records. Neither PDF is a standalone program.

The export manifest records the source hash, cell coverage, selected output
representations and display changes. The checks file records all-page bounds
checks, complete code-text recovery and preservation of all nine saved plots.
Original planning sections and earlier development observations are retained;
they are not new evidence that an unfinished project task has been completed.

No notebook cells, training jobs, source searches or model requests were run
to prepare these static exports. The original notebook was not changed.
